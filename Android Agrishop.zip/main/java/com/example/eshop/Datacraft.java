package com.example.eshop;

public class Datacraft {

    String FName;
    String Pname;
    String Category;
    String Img;
    String Price;
    String status;
    String cart;

    String femail;
    String uemail;
    String bulk;
    String Code;
    String id;
    String qty;
    String accfb;
    public Datacraft(){}
    public String getAccFb() { return accfb;
    }
    public void setAccFb(String accfb) {this.accfb = accfb;
    }
    public String getQty() { return qty;
    }
    public void setQty(String qty) {this.qty = qty;
    }
    public String getId() { return id;
    }
    public void setId(String id) {this.id = id;
    }
    public String getCode() {
        return Code;
    }
    public void setCode(String Code) {this.Code = Code;
    }
    public String getFName() {
        return FName;
    }
    public void setFName(String FName) {this.FName = FName;
    }
    public String getPname() {
        return Pname;
    }
    public void setPname(String Pname) {this.Pname = Pname;
    }
    public String getCategory() {
        return Category;
    }
    public void setCategory(String Category) {this.Category = Category;
    }
    public String getImg() {
        return Img;
    }
    public void setImg(String Img) {this.Img = Img;
    }
    public String getPrice() {
        return Price;
    }
    public void setPrice(String Price) {this.Price = Price;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {this.status = status;
    }
    public String getCartN() {
        return cart;
    }
    public void setCartN(String cart) {this.cart = cart;
    }
    public String getFEmail() {
        return femail;
    }
    public void setFEmail(String femail) {this.femail = femail;
    }
    public String getUEmail() {
        return uemail;
    }
    public void setUEmail(String uemail) {this.uemail = uemail;
    }
    public String getBulk() {
        return bulk;
    }
    public void setBulk(String bulk) {this.bulk = bulk;
    }
}
