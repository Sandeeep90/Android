package com.example.eshop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FbAcc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fb_acc);
    }
}